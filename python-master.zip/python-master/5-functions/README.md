# Functions

- [Function Concepts](function-concepts.md): function concept, definition and call. [YouTube Video](https://youtu.be/BV2AE2lmSq4)
- [`main` and Scope](main-and-scope.md): the `main` function and variable scopes. [YouTube Video](https://youtu.be/rXF1BgkU5qs)
- [Module](module.md): module concepts and built-in modules. [YouTube Video](https://youtu.be/Q8GHvsXhmIQ)
