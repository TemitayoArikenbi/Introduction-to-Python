import turtle

# Task1: Setup the window 600 * 600
SCREEN_WIDTH = 600    # Screen width
SCREEN_HEIGHT = 600   # Screen height
def setup_window():
    turtle.setup(SCREEN_WIDTH, SCREEN_HEIGHT)