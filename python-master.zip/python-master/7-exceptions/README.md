# Exceptions

- [Errors and Exceptions](errors-and-exceptions.ipynb): program errors and exceptions. [YouTube Video](https://youtu.be/gj9IiLCYnJQ).
- [Handling Exception](handling-exception.ipynb): handling program exception. [YouTube Video](https://youtu.be/jj9MVm-VqwU).
