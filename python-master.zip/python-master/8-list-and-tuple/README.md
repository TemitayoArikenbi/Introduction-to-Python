# List and Tuple

- [List Note](list.ipynb)
- [Tuple Note](tuple.md)
- [Lists Youtube Video](https://youtu.be/tw7ror9x32s)
