# Files

- [Read and Write](read-write.ipynb): read and write files. [YouTube Video](https://youtu.be/ScAbLiS8EXA).
- [Record and Operation](record-and-operation.ipynb): record and other file operations. [YouTube Video](https://youtu.be/LaLFBY3yubY).
