# Dictionary and Set

- [Dictionary Note](dictionary.ipynb)
- [Dictionary Youtube Video](https://youtu.be/ZEZdys-fHDw)
- [Set Youtube Video](https://youtu.be/r3R3h5ly_8g)
