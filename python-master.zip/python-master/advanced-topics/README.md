# Mutability and Object

- [Data Visualization Note](data-visualization.ipynb)
- [Data Science Note](data-science.ipynb)

- [Mutablity note](mutability.ipynb)
- [Class and Object note](class-and-object.ipynb)
- Classes and Objects YouTube Videos
  - [Part1](https://youtu.be/wfcWRAxRVBA)
  - [Part2](https://youtu.be/WOwi0h_-dfA)
